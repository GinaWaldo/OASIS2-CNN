import PIL as pil, pandas as pd, numpy as np
import shutil, os
from PIL import Image

#Parámetros definidos por el usuario
particionesDeseadas = 10
fraccionParticion = 0.75
images_src_directory = r'particionADNI/'
images_dest_directory = images_src_directory+"PARTICIONES/"
include_all_patient_images = True
   
#Obtiene los subdirectorios del directorio fuente (OASISTRAIN1SR). 
entries = os.scandir(images_src_directory)
subdirs = [entry.name for entry in entries if entry.is_dir()]
#Remueve subdirectorio PARTICIONES en caso de existir.
if('PARTICIONES' in subdirs):
    subdirs.remove('PARTICIONES')    
    try:
        shutil.rmtree(images_dest_directory)
        print("Directory "+images_dest_directory+" was removed successfully")
    except OSError as o:
        print(f"Error, {o.strerror}: {images_dest_directory}")

#Obtiene los nombres de todas las imágenes por subdirectorio
image_filenamesDict = {}
classes = []
allimage_filenames = []
allclasses = []
for subdir in subdirs:
    image_filenames = next(os.walk(r''+images_src_directory+subdir+'/'), (None, None, []))[2] 
    classes = [subdir for i in range(len(image_filenames))]
    image_filenamesDict[subdir] = image_filenames
    allimage_filenames = allimage_filenames + image_filenames
    allclasses = allclasses + classes
    
#Convierte las listas de imágenes y clases a un Dataframe
df = pd.DataFrame(  {'image_filename': allimage_filenames, 'class': allclasses })        

#Obtiene los índices de los pacientes y los filtra en un nuevo dataframe (D)
D = df['image_filename'].str[5:9].drop_duplicates()
allPatientsDf = df.iloc[D.index]

#Realiza el muestreo estratificado. Cada iteración da una secuencia de aleatorios distinta
indicesParticionesEntrenamiento = []
indicesParticionesPrueba = []
for p in np.arange(particionesDeseadas):
    tempDataFrame = allPatientsDf.groupby('class', group_keys=False).apply(lambda x: x.sample(frac=fraccionParticion))
    indicesParticionesEntrenamiento.append(tempDataFrame)
    indicesParticionesPrueba.append(allPatientsDf[~allPatientsDf.isin(tempDataFrame.to_dict('list')).all(axis=1)])

#Crea directorio PARTICIONES dentro del directorio fuente
if( not os.path.isdir(images_dest_directory)):
    os.mkdir(images_dest_directory)

#Imprimiendo archivo con datos de particiones de entrenamiento
allTrainingPartitions = pd.concat(indicesParticionesEntrenamiento, axis=1)
status = allTrainingPartitions.to_csv(images_dest_directory+"allTrainingPartitions.csv")
print(images_dest_directory+"allTrainingPartitions.csv"+" was written successfully")
allTestPartitions = pd.concat(indicesParticionesPrueba, axis=1)
status = allTestPartitions.to_csv(images_dest_directory+"allTestPartitions.csv")
print(images_dest_directory+"allTestPartitions.csv"+" was written successfully")

def saveImagePartitions(partitionIndexDataFrame, training_test_label):
    #Crea subdirectorios con todas las particiones solicitadas.
    for i,idxDataframe in enumerate(partitionIndexDataFrame):
        #Crea subdirectorios para la nueva partición
        sufixDir ="Particion"+str(i+1)+training_test_label+"/"
        if( not os.path.isdir(images_dest_directory+sufixDir)):
            os.mkdir(images_dest_directory+sufixDir)
            for classDir in subdirs:
                if( not os.path.isdir(images_dest_directory+sufixDir+classDir)):
                    os.mkdir(images_dest_directory+sufixDir+classDir)
                    
        if(include_all_patient_images):
            # Añade las imágenes extra de cada paciente 
            Q = (idxDataframe['image_filename'].str[:9]) #OAS2_####
            pattern = '|'.join(list(Q))
            R = df['image_filename'].str[:9].str.match(pattern)
            S = df[R]
        
            for idx, row in S.iterrows():        
                img = Image.open(images_src_directory+row['class']+"/"+row['image_filename'])
                dest = images_dest_directory+sufixDir+row['class']+"/"+row['image_filename']
                written= img.save(dest)
                #print(row['image_filename'],row['class'], ".... written in ",dest, "= ",written)
            #Guarda el dataframe en csv para validar las imágenes seleccionadas en la partición
        idxDataframe.to_csv(images_dest_directory+sufixDir+"partition "+training_test_label+" data.csv")

saveImagePartitions(indicesParticionesEntrenamiento,training_test_label=" (training)")
saveImagePartitions(indicesParticionesPrueba,training_test_label=" (test)")